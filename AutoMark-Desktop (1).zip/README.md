# AutoMark Desktop (Windows, Offline)

An offline QR-based autonomous attendance system built with Electron.
- Works fully **offline**
- Uses your **webcam** to scan QR codes (via `BarcodeDetector` API)
- Stores attendance records as a local JSON file in the app's userData folder

## Run (Development)
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the app:
   ```bash
   npm start
   ```

## Build Windows Installer
```bash
npm run dist
```
The installer (.exe) will be created in the `dist/` folder.

## Usage
- **Home**: overview & quick actions
- **Scan**: grant camera permission, select camera, scan QR codes
- **Records**: view, search, export CSV, clear records

> Tip: Encode a unique Name/ID in each QR code for clean logs (e.g., `STU-001`).

## Notes
- The BarcodeDetector API is supported on modern Chromium (bundled with Electron). If unsupported on your GPU/driver, install a virtual camera or update graphics drivers.

