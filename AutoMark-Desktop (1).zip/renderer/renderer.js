const pages = ['home','scan','records']
const navButtons = document.querySelectorAll('.navbtn, .actions [data-page]')
navButtons.forEach(btn=>btn.addEventListener('click', ()=>showPage(btn.dataset.page)))

function showPage(id){
  pages.forEach(p=>document.getElementById('page-'+p).classList.remove('show'))
  document.getElementById('page-'+id).classList.add('show')
  document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active', b.dataset.page===id))
  if(id==='scan'){ startScanner() } else { stopScanner() }
  if(id==='records'){ loadRecords() }
}
showPage('home')

// Storage helpers via preload
async function readRecords(){ return await window.AutoMark.readRecords() }
async function writeRecords(records){ return await window.AutoMark.writeRecords(records) }

// Records table
const tableBody = document.querySelector('#recordsTable tbody')
const search = document.getElementById('search')
const btnClear = document.getElementById('btnClear')
const btnExport = document.getElementById('btnExport')

let allRecords = []
search.addEventListener('input', ()=>renderTable())
btnClear.addEventListener('click', async ()=>{
  if(confirm('Clear all records?')){
    allRecords = []
    await writeRecords(allRecords)
    renderTable()
  }
})
btnExport.addEventListener('click', ()=>{
  const rows = [['Data','Time'], ...allRecords.map(r=>[r.text, new Date(r.time).toLocaleString()])]
  const csv = rows.map(r=>r.map(f=>`"${String(f).replaceAll('"','""')}"`).join(',')).join('\n')
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'})
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = 'automark-records.csv'
  a.click()
})

async function loadRecords(){
  allRecords = await readRecords() || []
  renderTable()
}

function renderTable(){
  const q = (search.value||'').toLowerCase()
  tableBody.innerHTML = ''
  const items = allRecords.filter(r=>r.text.toLowerCase().includes(q))
  for(const r of items){
    const tr = document.createElement('tr')
    tr.innerHTML = `<td class="mono">${escapeHtml(r.text)}</td><td>${new Date(r.time).toLocaleString()}</td>`
    tableBody.appendChild(tr)
  }
  if(items.length===0){
    const tr = document.createElement('tr')
    tr.innerHTML = `<td colspan="2" class="muted small">No records.</td>`
    tableBody.appendChild(tr)
  }
}

function escapeHtml(s){ return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])) }

// Scanner
let currentStream = null
let detector = null
const video = document.getElementById('video')
const overlay = document.getElementById('overlay')
const ctx = overlay.getContext('2d')
const scanStatus = document.getElementById('scanStatus')
const lastScan = document.getElementById('lastScan')
const cameraSelect = document.getElementById('cameraSelect')

async function listCameras(){
  try{
    const devices = await navigator.mediaDevices.enumerateDevices()
    const cams = devices.filter(d=>d.kind==='videoinput')
    cameraSelect.innerHTML = ''
    cams.forEach((c,idx)=>{
      const opt = document.createElement('option')
      opt.value = c.deviceId
      opt.textContent = c.label || `Camera ${idx+1}`
      cameraSelect.appendChild(opt)
    })
    return cams
  }catch(e){
    scanStatus.textContent = 'Could not list cameras: '+e.message
    return []
  }
}
cameraSelect.addEventListener('change', ()=>startScanner(cameraSelect.value))

async function startScanner(deviceId){
  stopScanner()
  try{
    // Ensure BarcodeDetector support
    if(!('BarcodeDetector' in window)){
      scanStatus.textContent = 'BarcodeDetector not supported on this system.'
      return
    }
    detector = new BarcodeDetector({ formats: ['qr_code'] })
    const constraints = { video: deviceId ? {deviceId: {exact: deviceId}} : { facingMode: 'environment' } }
    currentStream = await navigator.mediaDevices.getUserMedia(constraints)
    video.srcObject = currentStream
    await video.play()
    overlay.width = video.videoWidth
    overlay.height = video.videoHeight
    await listCameras()
    if(deviceId){ cameraSelect.value = deviceId }
    scanStatus.textContent = 'Scanning…'
    requestAnimationFrame(tick)
  }catch(e){
    scanStatus.textContent = 'Camera error: '+e.message
  }
}

function stopScanner(){
  if(currentStream){
    currentStream.getTracks().forEach(t=>t.stop())
    currentStream = null
  }
  if(ctx){ ctx.clearRect(0,0,overlay.width, overlay.height) }
}

let lastDrawTime = 0
async function tick(ts){
  if(!currentStream) return
  if(ts - lastDrawTime > 120){ // ~8 fps detect
    lastDrawTime = ts
    try{
      const barcodes = await detector.detect(video)
      ctx.clearRect(0,0,overlay.width, overlay.height)
      if(barcodes && barcodes.length){
        const code = barcodes[0]
        drawBox(code.boundingBox)
        onDetect(code.rawValue || code.displayValue || '')
      }
    }catch(e){
      // ignore transient detect errors
    }
  }
  requestAnimationFrame(tick)
}

function drawBox(box){
  ctx.strokeStyle = '#22c55e'
  ctx.lineWidth = 4
  ctx.strokeRect(box.x, box.y, box.width, box.height)
}

let lastValue = ''
let lastTime = 0
async function onDetect(value){
  if(!value) return
  const now = Date.now()
  if(value === lastValue && (now - lastTime) < 2000) return // debounce duplicates within 2s
  lastValue = value; lastTime = now
  scanStatus.textContent = 'Detected: '+value
  lastScan.textContent = value + ' • ' + new Date().toLocaleString()
  // persist
  const rec = { text: value, time: new Date().toISOString() }
  const existing = await readRecords() || []
  existing.unshift(rec)
  await writeRecords(existing)
}

