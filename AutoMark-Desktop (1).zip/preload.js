import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('AutoMark', {
  readRecords: () => ipcRenderer.invoke('records:read'),
  writeRecords: (records) => ipcRenderer.invoke('records:write', records)
})
